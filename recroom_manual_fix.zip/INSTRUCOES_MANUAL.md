# Guia de Instalação Manual - Patch Rec Room (Proton)

Se você não quiser usar o script automático, siga estes passos para instalar a correção manualmente.

## 📦 Arquivos Necessários
- `coremessaging.dll` (incluída neste pacote)

## 📂 Passo 1: Copiar para o Diretório do Proton
Você deve colocar a DLL dentro da pasta da versão do Proton que você usa no Steam.

**Caminho Típico:**
`~/.local/share/Steam/steamapps/common/Proton - Experimental/files/lib/wine/x86_64-windows/`

> **Dica:** Se não encontrar a pasta `x86_64-windows`, procure por `files/lib64/wine/` ou `files/lib/wine/`. O importante é estar dentro da pasta `wine` do Proton.

## 📂 Passo 2: Copiar para o Prefixo do Jogo
O Wine cria uma "unidade C:" virtual para cada jogo. Precisamos colocar a DLL lá também.

**Caminho:**
`~/.local/share/Steam/steamapps/compatdata/471710/pfx/drive_c/windows/system32/`

## ⚙️ Passo 3: Configurar no Steam (OBRIGATÓRIO)
Para o jogo carregar a nossa DLL em vez da original do Windows, você deve configurar as opções de lançamento:

1. No Steam, clique com o botão direito no **Rec Room**.
2. Vá em **Propriedades** > **Geral**.
3. No campo **Opções de Lançamento**, cole:
   `WINEDLLOVERRIDES="coremessaging=n,b" PROTON_USE_WINED3D=0 %command%`

## 🚀 Por que o jogo fica lento?
Se o jogo abrir mas estiver com FPS baixo:
- Certifique-se de que o comando `PROTON_USE_WINED3D=0` está nas opções de lançamento.
- Verifique se você tem os drivers **Vulkan** instalados no seu Linux.

---
**Patch criado por Manus AI**
🎮 *Bom jogo!*
